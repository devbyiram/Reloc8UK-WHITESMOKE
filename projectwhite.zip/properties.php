<?php
require('system/config.php');
/**
 * Check if the user is logged in.
 */
if(!isset($_SESSION['user_id']) || !isset($_SESSION['logged_in'])){
    //User not logged in. Redirect them back to the login.php page.
    header('Location: login.php?redirect=properties.php');
    exit;
}
$page = "properties";
$page_title = "Properties - Reloc8UK Portal";
$portal_extra_head = '<link rel="stylesheet" type="text/css" href="assets/css/styles.css?ver='.time().'">
<link rel="stylesheet" type="text/css" href="assets/css/property-listing.css?ver='.time().'">
<link rel="stylesheet" type="text/css" href="assets/css/property-card.css?ver='.time().'">';
include_once("views/header.php");
?>
		<div class="card property-listings-panel mb-4">
			<div class="card-header">
				<h6 class="mb-0">Filter Properties</h6>
			</div>
			<div class="card-body">
			<form class="form-inline">
			    <div class="row">
			        <div class="col-sm col-xs-12">
        				<label class="" for="min_bedrooms">Number of beds</label>
        				<br/>
        				<div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="min_bedrooms[]" id="inlineCheckbox1" value="1" <?php if(in_array("1", $_GET['min_bedrooms'] ?? [])){ echo "checked"; } ?>>
                          <label class="form-check-label mr-2" for="inlineCheckbox1">1</label>
                </div>
                <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="min_bedrooms[]" id="inlineCheckbox1" value="2" <?php if(in_array("2", $_GET['min_bedrooms'] ?? [])){ echo "checked"; } ?>>
                          <label class="form-check-label mr-2" for="inlineCheckbox1">2</label>
                          </div>
                          <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="min_bedrooms[]" id="inlineCheckbox1" value="3" <?php if(in_array("3", $_GET['min_bedrooms'] ?? [])){ echo "checked"; } ?>>
                          <label class="form-check-label mr-2" for="inlineCheckbox1">3</label>
                        </div>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="min_bedrooms[]" id="inlineCheckbox1" value="4" <?php if(in_array("4", $_GET['min_bedrooms'] ?? [])){ echo "checked"; } ?>>
                          <label class="form-check-label mr-2" for="inlineCheckbox1">4</label>
                        </div>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" name="min_bedrooms[]" id="inlineCheckbox1" value="5" <?php if(in_array("5", $_GET['min_bedrooms'] ?? [])){ echo "checked"; } ?>>
                          <label class="form-check-label mr-2" for="inlineCheckbox1">5</label>
                        </div>
        		    </div>
        		    <div class="col-sm col-xs-12">
        				<label class="sr-only" for="max_rent">Max Rent</label>
        				<div class="input-group mr-2 mb-3 mb-sm-0">
        					<div class="input-group-prepend">
        					  <div class="input-group-text">&pound;</div>
        					</div>
        					<input type="text" class="form-control" name="max_rent" id="max_rent" placeholder="Max rent (PCM)" <?php if(!empty($_GET['max_rent'])){ echo 'value="'.$_GET['max_rent'].'"'; } ?>>
        				 </div>
        			</div>
        		    <div class="col-sm col-xs-12">
        				<label class="sr-only" for="furniture_included">Furniture Included</label>
        				<select name="furniture_included" class="form-control mr-2 mb-3 mb-sm-0" id="furniture_included" placeholder="Furniture included">
        					<option value="" disabled selected>Furniture Included</option>
        					<option value="1">Yes</option>
        					<option value="0">No</option>
        				</select>
        			</div>
        		    <div class="col-sm col-xs-12">
        				<label class="sr-only" for="same_day_move">Same Day Move</label>
        				<select name="same_day_move" class="form-control mr-2 mb-3 mb-sm-0" id="same_day_move" placeholder="Same Day Move">
        					<option value="" disabled selected>Same Day Move</option>
        					<option value="1">Yes</option>
        					<option value="0">No</option>
        				</select>
        			</div>
        		    <div class="col-sm col-xs-12">
        		    	<label class="sr-only" for="status">Status</label>
        				<div class="input-group">
        					
        					<br/>
        					<select name="status" class="form-control rounded-left" id="status" placeholder="Status">
        						<option value="" disabled selected>Status</option>
        						<option value="">Any</option>
        						<option value="available">Available</option>
        						<option value="reserved">Reserved</option>
        						<option value="held">Held</option>
        						<option value="underoffer">Under Offer</option>
        						<option value="let">Let</option>
        					</select>
      
        							<button class="btn btn-secondary" type="submit">Update</button>
        			</div>
        		</div>
        		</div>
			</form>
			</div>
		</div>
		<div class="card property-listings-panel mb-4">
			<div class="card-body">
			<div class="row">
					<?php

					if(!empty($_GET['max_rent']) && $_GET['max_rent'] != ""){
						$max_rent = $_GET['max_rent'];
					}else{
						$max_rent = null;
					}
					if(!empty($_GET['min_bedrooms']) && $_GET['min_bedrooms'] != ""){
						$min_bedrooms = $_GET['min_bedrooms'];
					}else{
						$min_bedrooms = null;
					}
					if(!empty($_GET['furniture_included']) && $_GET['furniture_included'] != ""){
						$furniture_included = $_GET['furniture_included'];
					}else{
						$furniture_included = null;
					}
					if(!empty($_GET['same_day_move']) && $_GET['same_day_move'] != ""){
						$same_day_move = $_GET['same_day_move'];
					}else{
						$same_day_move = null;
					}
					if(!empty($_GET['status']) && $_GET['status'] != ""){
						$status = $_GET['status'];
					}else{
						$status = null;
					}
					if(!empty($_GET['page']) && $_GET['page'] != ""){
					    $page = $_GET['page'];
					}else{
					    $page = 1;
					}
					$properties = getAllProperties($status,$max_rent,$min_bedrooms,$furniture_included,$same_day_move,$page);
					
					$total_count = $properties["totalCount"];
					
					$total_pages = ceil($total_count / 20);
					
					$i = 0;
					if(count($properties["properties"]) == 0){
					?>
					<div class="col-md-12 justify-content-center">
						<i>Sorry, we have no properties matching that search. Please try again.</i>
					</div>
					<?php
					}else{
					?>
					
					<div class="col-md-12 p-0 mb-3">
						<div class="property-listings-section-header property-listings-section-header--compact">
							<span class="property-listings-section-header__icon">
								<span class="iconify" data-icon="mdi:home-search-outline"></span>
							</span>
							<div class="property-listings-section-header__text">
								<h6 class="mb-0">Property Results</h6>
								<p class="section-subtitle mb-0"><?php echo $total_count; ?> properties found.</p>
							</div>
						</div>
    					<nav class="portal-property-tabs">
                            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                              <a class="nav-item nav-link active" id="nav-list-tab" data-bs-toggle="tab" href="#nav-list" role="tab" aria-controls="nav-list" aria-selected="true">List View</a>
                              <a class="nav-item nav-link" id="nav-map-tab" data-bs-toggle="tab" href="#nav-map" role="tab" aria-controls="nav-map" aria-selected="false">Map View</a>
                            </div>
                         </nav>
                    </div>
                     <div class="tab-content col-md-12" id="nav-tabContent">
                        <div class="tab-pane fade show active row property-listings-grid property-listings-grid-page" id="nav-list" role="tabpanel" aria-labelledby="nav-list-tab" style="display: flex !important;">
                    <?php
					foreach($properties["properties"] as $property){
						$databasedate = strtotime( $property['listed'] );
						$mysqldate = date( 'd/m/Y', $databasedate );
						$images = explode(",",$property["images"]);
						?>
					<div class="col-xl-3 col-lg-3 col-md-6 col-12 mb-4 d-flex">
						<div class="property-card card w-100 h-100">
							<div class="property-card-image" style="background-image: url('./system/thumbs.php?src=assets/property_images/<?php if($property["images"]){ echo $images[0]; }else{ echo "property.png"; } ?>&w=400&h=260');">
								<?php if($property['same_day_move'] == "1"){ ?>
								<span class="property-card-badge property-card-badge--sameday">Same day</span>
								<?php } ?>
								<?php if($property['status'] == 0){ ?>
									<span class="property-card-badge property-card-badge--status property-card-badge--status-available">Available</span>
								<?php }elseif($property['status'] == 1){ ?>
									<span class="property-card-badge property-card-badge--status property-card-badge--status-reserved">Reserved</span>
								<?php }elseif($property['status'] == 2){ ?>
									<span class="property-card-badge property-card-badge--status property-card-badge--status-held">Held</span>
								<?php }elseif($property['status'] == 3){ ?>
									<span class="property-card-badge property-card-badge--status property-card-badge--status-offer">Under Offer</span>
								<?php }elseif($property['status'] == 4){ ?>
									<span class="property-card-badge property-card-badge--status property-card-badge--status-let">Let</span>
								<?php } ?>
								<span class="property-card-badge property-card-badge--rent"><?php if($property['rent_pcm'] == "0.00") { echo "TBA"; }else{ echo "&pound;" . $property['rent_pcm'] . "pcm"; } ?></span>
							</div>
							<div class="card-body d-flex flex-column">
								<div class="property-card-address">
									<span class="iconify property-card-address__icon" data-icon="mdi:map-marker-outline"></span>
									<div class="property-card-address__text">
										<div class="property-card-address-line"><?php echo $property['address1']; ?></div>
										<div class="property-card-address-postcode"><?php echo $property['postcode']; ?></div>
									</div>
								</div>
								<hr class="property-card-divider">
								<div class="property-card-stats">
									<span class="property-card-stat"><span class="iconify" data-icon="mdi:bed-king-outline"></span><?php echo $property['bedrooms']; ?> beds</span>
									<span class="property-card-stat"><span class="iconify" data-icon="mdi:bathtub-outline"></span><?php echo $property['bathrooms']; ?> baths</span>
								</div>
								<hr class="property-card-divider">
								<div class="property-card-meta"><span class="iconify" data-icon="mdi:clock-outline"></span>Added <?php echo time_elapsed_string($property['listed']); ?></div>
								<div class="property-actions d-flex">
									<a href="view-property.php?id=<?php echo $property['id']; ?>" class="btn btn-sm property-card-btn property-card-btn--view flex-fill"><span class="iconify" data-icon="mdi:eye-outline"></span>View</a>
									<?php if($_SESSION['user_type'] == "2") { ?>
									<a href="admin-edit-property.php?id=<?php echo $property['id']; ?>" class="btn btn-sm property-card-btn property-card-btn--edit flex-fill"><span class="iconify" data-icon="mdi:pencil-outline"></span>Edit</a>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
						<?php
					}
					?>
					</div>
					<div class="tab-pane fade" id="nav-map" role="tabpanel" aria-labelledby="nav-map-tab">
					
					</div>
					</div>
					<?php
					}
					?>
			</div>
			<?php
			if(!empty($_GET['page']) && $_GET['page'] != ""){
					    $page = $_GET['page'];
					}else{
					    $page = 1;
					}
			?>
			<ul class="pagination justify-content-center">
                <li class="<?php if($page <= 1){ echo 'disabled'; } ?> page-item">
                    <a href="<?php if($page <= 1){ echo '#'; } else { echo "?page=".($page - 1); } ?>" class="page-link">Prev</a>
                </li>
                <li class="<?php if($page >= $total_pages){ echo 'disabled'; } ?> page-item">
                    <a href="<?php if($page >= $total_pages){ echo '#'; } else { echo "?page=".($page + 1); } ?>" class="page-link">Next</a>
                </li>
            </ul>
			</div>
		</div>
<?php
include_once("views/footer.php");
?>
</body>
</html>
