<?php
session_start();
date_default_timezone_set("Europe/London");
// Require functions.php
// Database Credentials
define('MYSQL_HOST', 'localhost');
define('MYSQL_USER', 'root');
define('MYSQL_DB', 'whitesmoke');
define('MYSQL_PASS', '');

require('connect.php');
require('functions.php');
require('propertyfunctions.php');
