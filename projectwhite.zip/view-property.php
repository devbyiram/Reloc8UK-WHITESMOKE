<?php
require('system/config.php');
 
/**
 * Check if the user is logged in.
 */
if(!empty($_GET['share']) && $_GET['share'] == "true"){
	
}else{
	if(!isset($_SESSION['user_id']) || !isset($_SESSION['logged_in'])){
		//User not logged in. Redirect them back to the login.php page.
		header('Location: login.php?redirect=view-property.php');
		exit;
	}
}
$property = getProperty($_GET['id']);
if(isset($property['images'])){
	$property_images = explode(',',$property['images']);
}else{
	$property_images[0] = "property.png";
}
$page = "properties";
$page_title = 'View Property #' . $property['id'] . ' - ' . $property['address1'];
if(!empty($_GET['share']) && $_GET['share'] == "true"){
	$portal_hide_navbar = true;
}
$portal_extra_head = '<link type="text/css" rel="stylesheet" href="assets/css/flexslider.css" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="assets/js/jquery.flexslider.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.1/css/lightbox.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.1/js/lightbox.min.js"></script>';
include_once("views/header.php");
?>
	<main class="portal-main container portal-property-detail">
		<?php
			switch ($property['status']) {
				case 1:
					echo '<div class="my-2 alert alert-danger p-2 text-center"><i class="oi oi-warning"></i> This property is reserved</div>';
					break;
				case 2:
					echo '<div class="my-2 alert alert-warning p-2 text-center"><i class="oi oi-warning"></i> This property currently has interest in holding</div>';
					break;
				case 3:
					echo '<div class="my-2 alert alert-primary p-2 text-center"><i class="oi oi-warning"></i> This property is under offer</div>';
					break;
				case 4:
					echo '<div class="my-2 alert alert-danger p-2 text-center"><i class="oi oi-warning"></i> This property is let</div>';
					break;
				case 5:
				    echo '<div class="my-2 alert alert-info p-2 text-center"><i class="oi oi-warning"></i> This property will be available soon</div>';
				    break;
				case 6:
						echo '<div class="my-2 alert alert-danger p-2 text-center"><i class="oi oi-warning"></i> This property has now been assigned to a council</div>';
						break;
			}
		?>
		<?php
			if($_SESSION['user_type'] == 2){
		?>
		<div class="portal-card mb-4">
			<div class="portal-card-body">
			<div class="row">
				<div class="col-md-12">
					<p>Share a preview of this property to non-members. <a href="#" data-clipboard-text="https://www.reloc8uk.co.uk/portal/view-property.php?id=<?php echo $property['id']; ?>&share=true" class="copyToClipboard">Click to copy URL</a></p>
					<a href="admin-edit-property.php?id=<?php echo $property['id']; ?>" class="btn btn-secondary">Edit Property</a>
				</div>
			</div>
			</div>
		</div>
		<?php
			}
		?>
		<?php
			if(!empty($_GET['share']) && $_GET['share'] == "true"){
		?>
		<div class="alert alert-dark text-center my-2">
			You are visiting a preview of this property on the Reloc8UK portal.
		</div>
		<?php
			}
		?>
		<div class="portal-card mb-4">
			<div class="portal-card-body">
			<div class="row d-block d-sm-none">
				<div class="col-md-12">
					<h2 class="display-4"><?php echo $property['address1'] . ', ' . $property['postcode']; ?></h2>
					<div class="row">
						<div class="col-12 col-sm-6 text-center rounded text-white px-3 mb-3">
							<span class="bg-primary rounded py-2 d-block">
								Rent PCM: &pound;<?php echo $property['rent_pcm']; ?>
							</span>
						</div>
						<div class="col-12 col-sm-6 text-center rounded text-white px-3 mb-3">
							<span class="bg-secondary rounded py-2 d-block">
								Available: <?php if($property['available_soon'] == null) { echo date("d/m/Y",strtotime($property['date_available']));  } else { echo 'Available Soon'; }  ?>
							</span>
						</div>
					</div>
					
					<?php 
					if($property['same_day_move'] == 1) {
					?>
						<div class="alert alert-info m-2 text-center">
							<i class="oi oi-circle-check"></i> Same day move available on this property.
						</div>
					<?php
					}
					?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-5 col-xs-12">
					<div class="flexslider" id="slider" style="margin-bottom: 0 !important;">
						<ul class="slides">
							<?php
							
							foreach($property_images as $image){
								echo '<li data-thumb="assets/property_images/'.$image.'">';
								echo '<a data-lightbox="gallery" href="assets/property_images/'.$image.'"><img src="assets/property_images/'.$image.'"></a></li>';
							}
							?>
						</ul>
					</div>
					<div id="carousel" class="flexslider" style="margin-bottom: 0 !important;">
						<ul class="slides">
							<?php
							
							foreach($property_images as $image){
								echo '<li data-thumb="assets/property_images/'.$image.'">';
								echo '<img src="assets/property_images/'.$image.'"></li>';
							}
							?>
						</ul>
					</div>
				</div>
				<div class="col-md-7 col-xs-12 px-2">
					<div class="row">
						<div class="col-12 col-sm-6 text-center rounded text-white px-3 my-3 my-sm-1">
							<span class="bg-primary rounded py-2 d-block">
								Property type: <?php echo $propertyTypes[$property['property_type']]; ?>
							</span>
						</div>
						<div class="col-12 col-sm-6 text-center rounded text-white px-3 my-3 my-sm-1">
							<span class="bg-secondary rounded py-2 d-block">
								Available: <?php echo date("d/m/Y",strtotime($property['date_available'])); ?>
							</span>
						</div>
					</div>
				
					<div class="heading d-none d-sm-block">
						<h2 class="display-4"><?php echo $property['address1'] . ', ' . $property['postcode']; ?></h2>
						<h3><small class="text-muted">Rent PCM: <?php if($property['rent_pcm'] == "0.00") { echo "TBA"; }else{ echo "&pound;" . $property['rent_pcm']; } ?> | Date Available: <?php echo $property['date_available']; ?></small></h3>
					</div>
					<div class="property-body">
						<div class="row">
							<div class="col-md-4 col-xs-6 mb-4 col-sm-6 col-6 text-center">
								<span class="icon d-block">
									<img src="assets/img/sleep.png" width="48" alt="Bedrooms" />
								</span>
								<span class="label">Bedrooms</span>
								<span class="badge badge bg-primary d-block p-2"><?php echo $property['bedrooms']; ?></span>
							</div>
							<div class="col-md-4 col-xs-6 mb-4 col-sm-6 col-6 text-center">
								<span class="icon d-block">
									<img src="assets/img/furniture-and-household.png" width="48" alt="Bedrooms" />
								</span>
								<span class="label">Bathrooms</span>
								<span class="badge badge bg-primary d-block p-2"><?php echo $property['bathrooms']; ?></span>
							</div>
							<div class="col-md-4 col-xs-6 col-sm-6 mb-4 col-6 text-center">
								<span class="icon d-block">
									<img src="assets/img/sofa.png" width="48" alt="Bedrooms" />
								</span>
								<span class="label d-block">Furniture</span>
								<span class="badge badge bg-primary d-block p-2"><?php if($property['furniture_included'] == "1"){ echo '<i class="oi oi-check"></i>'; }else{ echo '<i class="oi oi-x"></i>'; } ?></span>
							</div>
							<div class="col-md-4 col-xs-6 mb-4 col-sm-6 col-6 text-center">
								<span class="icon d-block">
									<img src="assets/img/farming-and-gardening.png" width="48" alt="Bedrooms" />
								</span>
								<span class="label d-block">Front Garden</span>
								<span class="badge badge bg-primary d-block p-2"><?php if($property['garden_front'] == "1"){ echo '<i class="oi oi-check"></i>'; }else{ echo '<i class="oi oi-x"></i>'; } ?></span>
							</div>
							<div class="col-md-4 col-xs-6 mb-4 col-sm-6 col-6 text-center">
								<span class="icon d-block">
									<img src="assets/img/farming-and-gardening.png" width="48" alt="Bedrooms" />
								</span>
								<span class="label d-block">Rear Garden</span>
								<span class="badge badge bg-primary d-block p-2"><?php if($property['garden_rear'] == "1"){ echo '<i class="oi oi-check"></i>'; }else{ echo '<i class="oi oi-x"></i>'; } ?></span>
							</div>
							<div class="col-md-4 col-xs-6 mb-4 col-sm-6 col-6 text-center">
								<span class="icon d-block">
									<img src="assets/img/heater.png" width="48" alt="Bedrooms" />
								</span>
								<span class="label">Central Heating</span>
								<span class="badge badge bg-primary d-block p-2"><?php if($property['central_heating'] == "1"){ echo '<i class="oi oi-check"></i>'; }else{ echo '<i class="oi oi-x"></i>'; } ?></span>
							</div>
							
						</div>
					</div>
					<?php if(empty($_GET['share']) && $_GET['share'] != "true") { ?>
					<?php
					if($_SESSION['user_type'] != 3){
					?>
					<div class="property-actions py-4">
						<p class="lead">Property Actions</p>
						<div class="row">
						<?php
							if($property['status'] == 0 || $property['status'] == 2){
						?>
						    <?php
						        if($_SESSION['user_type'] != 4){
						    ?>
							<div class="col mb-1 my-2 my-sm-2 d-grid">
								<a href="reserve-property.php?id=<?php echo $property['id']; ?>" class="btn btn-lg btn-block btn-primary" title="Reserve this property for 24 hours" data-toggle="tooltip">Reserve</a>
							</div>
							<div class="col mb-1 my-2 my-sm-2 d-grid">
								<a href="hold-property.php?id=<?php echo $property['id']; ?>" class="btn btn-lg btn-block btn-secondary" title="Hold this property (holding fee required)" data-toggle="tooltip">Hold</a>
							</div>
							<?php
						        }
						    ?>
							<div class="col mb-1 my-2 my-sm-2 d-grid">
								<a href="offer-property.php?id=<?php echo $property['id']; ?>" class="btn btn-lg btn-block btn-warning" title="Offer this property to a tenant" data-toggle="tooltip">Offer</a>
							</div>
						<?php 
							}
						?>
							<!--<div class="col-6 col-sm-3 mb-1 my-2 my-sm-2">
								<a href="show-interest.php?pid=<?php echo $property['id']; ?>" class="btn btn-lg btn-block btn-dark showInterest" title="Show an interest in this property" data-toggle="tooltip" onclick="return confirm('Are your sure you want to show an interest in this property?')">Interested</a>
							</div>-->
						</div>
					</div>
					<?php
					}
					}
					?>
					<div class="property-info mt-2 mt-sm-2">
						<h6 class="border-bottom border-gray pb-2 mb-2 d-block">Additional Information</h6>
						<p class="lead"><?php echo nl2br($property['notes']); ?></p>
					</div>
				</div>
			</div>
			<?php 
				if($property['same_day_move'] == 1) {
				?>
				<div class="row p-2">
					<div class="alert alert-dark m-2 d-none d-sm-block mx-auto">
						<h4 class="alert-heading">Same Day Move Available!</h4>
						<p>This property is available for our same day move, meaning you could be in this property today!</p>
						<hr>
						<p>Reserve this property today!</p>
					</div>
				</div>
				<?php
				}
				?>
			<div class="row portal-property-links bg-light p-4 my-2">
				<div class="list-group list-group-horizontal-sm">
					<a href="https://www.checkmypostcode.uk/<?php echo str_replace(' ','',$property['postcode']); ?>"class="list-group-item list-group-item-action flex-column align-items-start bg-info text-white" target="_blank">
						<div class="d-flex w-100 justify-content-between">
							<h5 class="mb-1">CheckMyPostcode</h5>
						</div>
						<p class="mb-1">Find out further information regarding local schools, council, amenities and more.</p>
						<small>Click here to visit CheckMyPostcode.uk</small>
					</a>
					<a href="https://www.google.com/maps/place/<?php echo str_replace(' ','',$property['postcode']); ?>"class="list-group-item list-group-item-action flex-column align-items-start bg-dark text-light" target="_blank">
						<div class="d-flex w-100 justify-content-between">
							<h5 class="mb-1">Google Maps</h5>
						</div>
						<p class="mb-1">View the local area, including StreetView, on Google Maps.</p>
						<small>Click here to visit maps.google.com</small>
					</a>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 col-xs-12 pt-2">
					<h6 class="border-bottom border-gray pb-2 mb-2 d-block">Property Video <small class="text-muted">(if applicable)</small></h6>
					<div class="row px-4">
						<?php echo getPropertyVideo($property['id']); ?>
					</div>
				</div>
				<div class="col-md-6 col-xs-12 pt-2">
					<h6 class="border-bottom border-gray pb-2 mb-4 d-block">Property Files</h6>
					<div class="row">
					<?php
						echo getPropertyFiles($property['id']);
					?>
					</div>
				</div>
			</div>
			</div>
		</div>
	</main>
<?php
include_once("views/footer.php");
?>
<script type="text/javascript">
$(document).ready(function(){
	$(function () {
	  $('[data-toggle="tooltip"]').tooltip()
	})
});
</script>
<script>
$(window).load(function() {
  $('#slider').flexslider({
    animation: "slide",
    controlNav: false,
    animationLoop: true,
    slideshow: false,
    sync: "#carousel"
  });
  $('#carousel').flexslider({
    animation: "slide",
    controlNav: false,
    animationLoop: true,
    slideshow: false,
    itemWidth: 90,
    itemMargin: 5,
    asNavFor: '#slider'
  });
});
</script>
<script type="text/javascript" src="https://milankyncl.github.io/jquery-copy-to-clipboard/jquery.copy-to-clipboard.js"></script>
<script type="text/javascript">
$(document).ready(function() {
  $('.copyToClipboard').CopyToClipboard();
});
</script>
</body>
</html>
